from __future__ import absolute_import

import click
click.disable_unicode_literals_warning = True

from click import *  # noqa
