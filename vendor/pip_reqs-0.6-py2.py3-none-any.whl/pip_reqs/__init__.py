"""
Helpers for dealing with pip requirements
"""

__version__ = '0.6'
__url__ = 'https://github.com/divio/ac-wheelsproxy'
__author__ = 'Divio AG'
__email__ = 'info@divio.com'
__license__ = 'MIT'
